<?php
/**
 * Promo banner (home + form pages)
 */
?>
<div class="container-fluid" style="background: #dc3545;">
    <div class="py-2">
        <div class="d-flex flex-column flex-md-row align-items-start align-items-md-center justify-content-center gap-2">
            <div class="text-white text-center">
                <div class="fw-bold">Interested in a special discount?</div>
                <div class="small opacity-75">Bundle the Registration Process and the 6-month review class!</div>
            </div>
        </div>
    </div>
</div>
