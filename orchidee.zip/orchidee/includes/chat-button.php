<!-- Chat Button - Floating -->
<a href="https://api.dzidzoe.com/api/v1/w/697934e413cea54fd4e3253e" target="_blank" class="btn btn-primary btn-lg-square rounded-circle chat-button" title="Chat avec nous">
    <i class="fas fa-comments"></i>
</a>
