-- ============================================
-- Orchidee LLC - Database Export
-- Export Date: 2026-01-31 07:47:59
-- Database: orchidee
-- ============================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- Disable foreign key checks during import
SET FOREIGN_KEY_CHECKS = 0;

-- IMPORTANT : Dans phpMyAdmin, sélectionnez d'abord votre base de données puis importez ce fichier.
-- Sur hébergement mutualisé, ne pas exécuter CREATE DATABASE (droits refusés).

-- --------------------------------------------------------
-- Table structure for table `blog_posts`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `blog_posts`;
CREATE TABLE `blog_posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `featured_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','published') COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `author_id` int DEFAULT NULL,
  `views` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `blog_posts_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `blog_posts`
-- --------------------------------------------------------

INSERT INTO `blog_posts` (`id`, `title`, `content`, `excerpt`, `category`, `featured_image`, `status`, `author_id`, `views`, `created_at`, `updated_at`) VALUES
('1', 'Top 10 NCLEX Study Strategies That Work', '<p>Introduction</p><p><strong>Preparing for the NCLEX exam can be overwhelming, but with the right strategies, you can maximize your study time and boost your confidence. Here are the top 10 proven study strategies that have helped hundreds of nurses pass the NCLEX on their first attempt.</strong></p><h3>1. Create a Structured Study Schedule</h3><p>Consistency is key when preparing for the NCLEX. Create a daily study schedule that includes specific times for reviewing content, taking practice questions, and reviewing your mistakes. Stick to your schedule as much as possible to build a strong study habit.</p><h3>2. Focus on High-Yield Topics</h3><p>While it\'s important to review all content, prioritize high-yield topics that appear frequently on the exam. These include:</p><ul><li>Pharmacology and medication administration</li><li>Patient safety and infection control</li><li>Prioritization and delegation</li><li>Medical-surgical nursing</li><li>Mental health nursing</li></ul><h3>3. Practice with NCLEX-Style Questions</h3><p>Familiarize yourself with the NCLEX question format by practicing with hundreds of questions. Focus on understanding why answers are correct or incorrect, not just memorizing answers.</p><h3>4. Use Active Learning Techniques</h3><p>Instead of passively reading, engage in active learning:</p><ul><li>Create flashcards for key concepts</li><li>Teach concepts to others or explain them out loud</li><li>Draw diagrams and flowcharts</li><li>Use mnemonics for memorization</li></ul><h3>5. Join a Study Group</h3><p>Studying with peers can help you stay motivated and gain different perspectives on difficult topics. Join our OrchideeLLC study groups to connect with other NCLEX candidates.</p><h3>6. Take Regular Practice Exams</h3><p>Simulate the actual exam experience by taking full-length practice exams under timed conditions. This helps build stamina and reduces test anxiety.</p><h3>7. Review Your Mistakes Thoroughly</h3><p>Don\'t just move on after getting a question wrong. Take time to understand why you missed it and review the underlying concept. Keep a journal of your mistakes to identify patterns.</p><h3>8. Prioritize Self-Care</h3><p>Your physical and mental health directly impact your ability to study effectively. Ensure you get enough sleep, eat well, exercise, and take breaks to avoid burnout.</p><h3>9. Use Multiple Study Resources</h3><p>Don\'t rely on just one study resource. Combine textbooks, online courses, practice question banks, and video lectures to get a comprehensive understanding of the material.</p><h3>10. Stay Positive and Confident</h3><p>Believe in yourself and your preparation. Maintain a positive mindset and visualize yourself passing the exam. Confidence is a crucial component of NCLEX success.</p><h2>Conclusion</h2><p>Remember, passing the NCLEX is not just about memorizing facts—it\'s about understanding nursing concepts and applying critical thinking. With dedication, the right strategies, and support from OrchideeLLC, you can achieve your goal of becoming a licensed nurse in the United States.</p><p><strong>Ready to start your NCLEX journey?</strong> <a href=\"consultation.html\">Book a consultation</a> with our expert coaches today!</p>', 'Discover proven study strategies that have helped hundreds of nurses pass the NCLEX on their first attempt. Learn how to maximize your study time and boost your confidence.', 'NCLEX Tips', NULL, 'published', '1', '1', '2025-12-23 17:32:52', '2025-12-23 21:57:14'),
('2', 'Understanding Credential Evaluation for US Nursing', '<h2>Introduction</h2>\r\n    <p>If you\'re an internationally educated nurse looking to practice in the United States, understanding the credential evaluation process is essential. This comprehensive guide will walk you through everything you need to know about credential evaluation, required documents, timelines, and how to avoid common mistakes.</p>\r\n    \r\n    <h3>What is Credential Evaluation?</h3>\r\n    <p>Credential evaluation is the process of having your foreign nursing education and credentials assessed to determine their equivalency to U.S. nursing standards. This evaluation is required by most state boards of nursing before you can take the NCLEX and obtain a U.S. nursing license.</p>\r\n    \r\n    <h3>Why is Credential Evaluation Important?</h3>\r\n    <p>State boards of nursing need to verify that your education meets U.S. standards before allowing you to take the NCLEX. The evaluation ensures:</p>\r\n    <ul>\r\n        <li>Your nursing education is equivalent to U.S. nursing programs</li>\r\n        <li>You have completed the required coursework</li>\r\n        <li>Your clinical hours meet minimum requirements</li>\r\n        <li>Your credentials are authentic and valid</li>\r\n    </ul>\r\n    \r\n    <h3>Who Performs Credential Evaluations?</h3>\r\n    <p>Several organizations are authorized to perform credential evaluations for nurses:</p>\r\n    <ul>\r\n        <li><strong>Commission on Graduates of Foreign Nursing Schools (CGFNS)</strong> - Most commonly used</li>\r\n        <li><strong>Educational Records Evaluation Service (ERES)</strong></li>\r\n        <li><strong>International Education Research Foundation (IERF)</strong></li>\r\n    </ul>\r\n    <p>Check with your specific state board of nursing to determine which evaluation service they accept.</p>\r\n    \r\n    <h3>Required Documents for Credential Evaluation</h3>\r\n    <p>Gathering the correct documents is crucial for a smooth evaluation process. You will typically need:</p>\r\n    \r\n    <h4>1. Educational Documents</h4>\r\n    <ul>\r\n        <li>Official transcripts from your nursing school</li>\r\n        <li>Diploma or degree certificate</li>\r\n        <li>Course descriptions and syllabi</li>\r\n        <li>Clinical rotation records</li>\r\n    </ul>\r\n    \r\n    <h4>2. Professional Documents</h4>\r\n    <ul>\r\n        <li>Current nursing license from your home country</li>\r\n        <li>License verification from your licensing board</li>\r\n        <li>Employment verification letters</li>\r\n    </ul>\r\n    \r\n    <h4>3. Personal Documents</h4>\r\n    <ul>\r\n        <li>Valid passport</li>\r\n        <li>Birth certificate</li>\r\n        <li>Marriage certificate (if applicable)</li>\r\n        <li>Name change documents (if applicable)</li>\r\n    </ul>\r\n    \r\n    <h3>Common Mistakes to Avoid</h3>\r\n    <p>Many nurses encounter delays due to avoidable mistakes. Here are the most common issues:</p>\r\n    \r\n    <h4>1. Incomplete Documentation</h4>\r\n    <p>Missing or incomplete documents can delay your evaluation by weeks or months. Double-check all requirements before submitting.</p>\r\n    \r\n    <h4>2. Not Getting Documents Translated</h4>\r\n    <p>If your documents are not in English, you must have them professionally translated by a certified translator.</p>\r\n    \r\n    <h4>3. Using the Wrong Evaluation Service</h4>\r\n    <p>Each state board may accept different evaluation services. Verify which service your state requires before starting the process.</p>\r\n    \r\n    <h4>4. Not Following Up</h4>\r\n    <p>Keep track of your application status and follow up regularly. Don\'t assume everything is processing smoothly.</p>\r\n    \r\n    <h4>5. Waiting Too Long to Start</h4>\r\n    <p>The credential evaluation process can take 3-6 months or longer. Start early to avoid delays in your NCLEX timeline.</p>\r\n    \r\n    <h3>Timeline Expectations</h3>\r\n    <p>Understanding the timeline helps you plan effectively:</p>\r\n    <ul>\r\n        <li><strong>Document Gathering:</strong> 2-4 weeks</li>\r\n        <li><strong>Translation (if needed):</strong> 1-2 weeks</li>\r\n        <li><strong>Evaluation Processing:</strong> 8-12 weeks</li>\r\n        <li><strong>State Board Review:</strong> 4-8 weeks</li>\r\n    </ul>\r\n    <p><strong>Total Time:</strong> Approximately 4-6 months from start to finish</p>\r\n    \r\n    <h3>Tips for a Smooth Process</h3>\r\n    <ol>\r\n        <li><strong>Start Early:</strong> Begin gathering documents as soon as you decide to pursue U.S. licensure</li>\r\n        <li><strong>Stay Organized:</strong> Keep copies of all documents and correspondence</li>\r\n        <li><strong>Communicate Clearly:</strong> Respond promptly to any requests for additional information</li>\r\n        <li><strong>Seek Professional Help:</strong> Consider working with a credential evaluation service or consultant</li>\r\n        <li><strong>Be Patient:</strong> The process takes time, but thoroughness is more important than speed</li>\r\n    </ol>\r\n    \r\n    <h3>How OrchideeLLC Can Help</h3>\r\n    <p>At OrchideeLLC, we understand the challenges of the credential evaluation process. Our team provides:</p>\r\n    <ul>\r\n        <li>Step-by-step guidance through the entire process</li>\r\n        <li>Document checklist and review</li>\r\n        <li>Timeline planning and management</li>\r\n        <li>Support when issues arise</li>\r\n        <li>Coordination with evaluation services</li>\r\n    </ul>\r\n    \r\n    <h2>Conclusion</h2>\r\n    <p>Credential evaluation is a critical step in your journey to becoming a U.S. licensed nurse. While the process can seem daunting, proper preparation and organization can make it manageable. Remember, you don\'t have to navigate this alone—OrchideeLLC is here to support you every step of the way.</p>\r\n    \r\n    <p><strong>Need help with your credential evaluation?</strong> <a href=\"consultation.html\">Schedule a consultation</a> with our expert team today!</p>', 'Navigate the credential evaluation process with confidence. Learn what documents you need, timelines to expect, and how to avoid common mistakes that delay your application.', 'Licensure', NULL, 'published', '1', '3', '2025-12-23 17:32:52', '2026-01-26 15:22:52');

-- --------------------------------------------------------
-- Table structure for table `chapters`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `chapters`;
CREATE TABLE `chapters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `order_number` int NOT NULL DEFAULT '0',
  `is_locked` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  CONSTRAINT `chapters_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `chapters`
-- --------------------------------------------------------

INSERT INTO `chapters` (`id`, `course_id`, `title`, `description`, `order_number`, `is_locked`, `created_at`) VALUES
('1', '1', 'AZERTY', 'ZAERT', '1', '1', '2025-12-23 19:01:45');

-- --------------------------------------------------------
-- Table structure for table `course_categories`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `course_categories`;
CREATE TABLE `course_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `course_categories`
-- --------------------------------------------------------

INSERT INTO `course_categories` (`id`, `name`, `description`, `created_at`) VALUES
('1', 'NCLEX-RN Review', 'Comprehensive review courses for NCLEX-RN examination', '2025-12-15 19:08:55'),
('2', 'NCLEX-PN Review', 'Comprehensive review courses for NCLEX-PN examination', '2025-12-15 19:08:55'),
('3', 'Credential Evaluation', 'Guidance on credential evaluation process', '2025-12-15 19:08:55'),
('4', 'License Endorsement', 'Support for license endorsement process', '2025-12-15 19:08:55'),
('5', 'Resume Writing', 'Professional resume writing for nurses', '2025-12-15 19:08:55'),
('6', 'Interview Preparation', 'NCLEX and job interview preparation', '2025-12-15 19:08:55');

-- --------------------------------------------------------
-- Table structure for table `course_live_sessions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `course_live_sessions`;
CREATE TABLE `course_live_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course_id` int NOT NULL,
  `coach_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_date` date NOT NULL,
  `session_time` time NOT NULL,
  `meet_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration_minutes` int DEFAULT '60',
  `status` enum('scheduled','live','ended','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'scheduled',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `coach_id` (`coach_id`),
  KEY `session_date` (`session_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `course_live_sessions`
-- --------------------------------------------------------

INSERT INTO `course_live_sessions` (`id`, `course_id`, `coach_id`, `title`, `session_date`, `session_time`, `meet_url`, `duration_minutes`, `status`, `created_at`, `updated_at`) VALUES
('1', '10', '4', 'Session title', '2026-03-12', '12:00:00', 'https://meet.google.com/jss-toip-pfg', '60', 'scheduled', '2026-01-31 06:56:40', '2026-01-31 06:56:40');

-- --------------------------------------------------------
-- Table structure for table `courses`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `courses`;
CREATE TABLE `courses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `short_description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `instructor_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_hours` int DEFAULT '0',
  `level` enum('beginner','intermediate','expert') COLLATE utf8mb4_unicode_ci DEFAULT 'intermediate',
  `status` enum('draft','published') COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `visible_public` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `course_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `courses_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `courses`
-- --------------------------------------------------------

INSERT INTO `courses` (`id`, `title`, `description`, `short_description`, `price`, `image`, `category_id`, `instructor_name`, `duration_hours`, `level`, `status`, `created_by`, `created_at`, `updated_at`, `visible_public`) VALUES
('1', 'NCLEX-RN Comprehensive Review - Part 1', 'Master the fundamentals of NCLEX-RN with our comprehensive review course. Covering medical-surgical nursing, pharmacology, and patient care fundamentals.', 'Master NCLEX-RN fundamentals with comprehensive medical-surgical review.', '299.99', NULL, '1', 'Sandy Brice', '40', 'intermediate', 'published', '1', '2025-12-16 09:29:36', '2025-12-16 09:29:36', '1'),
('10', 'Title', 'Short descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort description', 'Short descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort descriptionShort description', '0.00', NULL, NULL, 'Ray Ray', '0', 'intermediate', 'published', '4', '2026-01-31 06:54:34', '2026-01-31 06:54:34', '0');

-- --------------------------------------------------------
-- Table structure for table `exam_answers`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `exam_answers`;
CREATE TABLE `exam_answers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `attempt_id` int NOT NULL,
  `question_id` int NOT NULL,
  `answer_text` text COLLATE utf8mb4_unicode_ci,
  `option_id` int DEFAULT NULL,
  `is_correct` tinyint(1) DEFAULT '0',
  `points_earned` decimal(5,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `exam_answers`
-- --------------------------------------------------------

-- No data in table `exam_answers`

-- --------------------------------------------------------
-- Table structure for table `exam_attempts`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `exam_attempts`;
CREATE TABLE `exam_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `exam_id` int NOT NULL,
  `user_id` int NOT NULL,
  `score` decimal(5,2) DEFAULT NULL,
  `passed` tinyint(1) DEFAULT '0',
  `time_taken_minutes` int DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `exam_attempts`
-- --------------------------------------------------------

-- No data in table `exam_attempts`

-- --------------------------------------------------------
-- Table structure for table `exam_question_options`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `exam_question_options`;
CREATE TABLE `exam_question_options` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question_id` int NOT NULL,
  `option_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_correct` tinyint(1) DEFAULT '0',
  `display_order` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `exam_question_options`
-- --------------------------------------------------------

-- No data in table `exam_question_options`

-- --------------------------------------------------------
-- Table structure for table `exam_questions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `exam_questions`;
CREATE TABLE `exam_questions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `exam_id` int NOT NULL,
  `question_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_type` enum('multiple_choice','true_false','essay','fill_blank') COLLATE utf8mb4_unicode_ci DEFAULT 'multiple_choice',
  `points` int DEFAULT '1',
  `display_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `exam_questions`
-- --------------------------------------------------------

-- No data in table `exam_questions`

-- --------------------------------------------------------
-- Table structure for table `exams`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `exams`;
CREATE TABLE `exams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course_id` int NOT NULL,
  `chapter_id` int DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `passing_score` int DEFAULT '70',
  `time_limit_minutes` int DEFAULT '60',
  `max_attempts` int DEFAULT '3',
  `display_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `exams`
-- --------------------------------------------------------

INSERT INTO `exams` (`id`, `course_id`, `chapter_id`, `title`, `description`, `passing_score`, `time_limit_minutes`, `max_attempts`, `display_order`, `created_at`) VALUES
('1', '1', '0', 'EXAM', 'EXAM', '70', '60', '3', '0', '2025-12-23 18:58:33');

-- --------------------------------------------------------
-- Table structure for table `form_fields`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `form_fields`;
CREATE TABLE `form_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `form_id` int NOT NULL,
  `field_type` enum('text','email','textarea','select','radio','checkbox','date','file','number') COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_options` text COLLATE utf8mb4_unicode_ci,
  `is_required` tinyint(1) DEFAULT '0',
  `display_order` int DEFAULT '0',
  `placeholder` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validation_rules` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `display_order` (`display_order`),
  CONSTRAINT `form_fields_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `service_forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `form_fields`
-- --------------------------------------------------------

-- No data in table `form_fields`

-- --------------------------------------------------------
-- Table structure for table `lesson_resources`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `lesson_resources`;
CREATE TABLE `lesson_resources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lesson_id` int DEFAULT NULL,
  `chapter_id` int DEFAULT NULL,
  `course_id` int DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` enum('pdf','doc','docx','ppt','pptx','image','video','audio','other') COLLATE utf8mb4_unicode_ci DEFAULT 'pdf',
  `file_size` int DEFAULT NULL,
  `display_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `lesson_resources`
-- --------------------------------------------------------

INSERT INTO `lesson_resources` (`id`, `lesson_id`, `chapter_id`, `course_id`, `title`, `file_url`, `file_type`, `file_size`, `display_order`, `created_at`) VALUES
('1', '0', '0', '1', 'AZERTYU', 'uploads/courses/resources/1766509082_9351afe0-9abc-475b-86c1-e75c31864d9e.jpeg', 'image', '142729', '1', '2025-12-23 18:58:02');

-- --------------------------------------------------------
-- Table structure for table `lessons`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `lessons`;
CREATE TABLE `lessons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chapter_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `video_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_type` enum('youtube','vimeo','upload','external') COLLATE utf8mb4_unicode_ci DEFAULT 'upload',
  `duration_minutes` int DEFAULT '0',
  `order_number` int NOT NULL DEFAULT '0',
  `is_locked` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `chapter_id` (`chapter_id`),
  CONSTRAINT `lessons_ibfk_1` FOREIGN KEY (`chapter_id`) REFERENCES `chapters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `lessons`
-- --------------------------------------------------------

-- No data in table `lessons`

-- --------------------------------------------------------
-- Table structure for table `nclex_registration_courses`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `nclex_registration_courses`;
CREATE TABLE `nclex_registration_courses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `registration_id` int NOT NULL,
  `course_id` int NOT NULL,
  `assigned_by` int DEFAULT NULL,
  `assigned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_assignment` (`registration_id`,`course_id`),
  KEY `idx_registration_id` (`registration_id`),
  KEY `idx_course_id` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `nclex_registration_courses`
-- --------------------------------------------------------

-- No data in table `nclex_registration_courses`

-- --------------------------------------------------------
-- Table structure for table `nclex_registrations`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `nclex_registrations`;
CREATE TABLE `nclex_registrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob_day` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob_month` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob_year` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_line1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `immigration_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_immigration_status` text COLLATE utf8mb4_unicode_ci,
  `elementary_school_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `elementary_address_line1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `elementary_address_line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `elementary_city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `elementary_state` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `elementary_zip_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `elementary_entry_date` date DEFAULT NULL,
  `elementary_exit_date` date DEFAULT NULL,
  `elementary_grade_from` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `elementary_grade_to` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `elementary_another_school` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `elementary_another_school_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_school_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_school_address_line1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_school_address_line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_school_city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_school_state` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_school_zip_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_school_entry_date` date DEFAULT NULL,
  `high_school_exit_date` date DEFAULT NULL,
  `high_school_grade_from` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_school_grade_to` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_school_another_school` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_school_another_school_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `university_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `university_address_line1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `university_address_line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `university_city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `university_state` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `university_zip_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `university_entry_date` date DEFAULT NULL,
  `university_exit_date` date DEFAULT NULL,
  `university_years` int DEFAULT NULL,
  `university_another` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `university_another_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `university_specialization` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specialization` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documents` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','reviewed','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_email` (`email`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `nclex_registrations`
-- --------------------------------------------------------

INSERT INTO `nclex_registrations` (`id`, `user_id`, `first_name`, `middle_name`, `last_name`, `dob_day`, `dob_month`, `dob_year`, `phone`, `email`, `address_line1`, `address_line2`, `city`, `state`, `zip_code`, `immigration_status`, `other_immigration_status`, `elementary_school_name`, `elementary_address_line1`, `elementary_address_line2`, `elementary_city`, `elementary_state`, `elementary_zip_code`, `elementary_entry_date`, `elementary_exit_date`, `elementary_grade_from`, `elementary_grade_to`, `elementary_another_school`, `elementary_another_school_name`, `high_school_name`, `high_school_address_line1`, `high_school_address_line2`, `high_school_city`, `high_school_state`, `high_school_zip_code`, `high_school_entry_date`, `high_school_exit_date`, `high_school_grade_from`, `high_school_grade_to`, `high_school_another_school`, `high_school_another_school_name`, `university_name`, `university_address_line1`, `university_address_line2`, `university_city`, `university_state`, `university_zip_code`, `university_entry_date`, `university_exit_date`, `university_years`, `university_another`, `university_another_name`, `university_specialization`, `specialization`, `documents`, `status`, `created_at`, `updated_at`) VALUES
('1', '2', 'Glen', '', 'Dempsey', '1', '03', '2006', '0965646608', 'mailsecours60@gmail.com', '63-65 Kilmacud Road Lower, Blackrock', '', 'Dublin', 'AK', 'A94 C840', 'Asylum Seeker', '', 'ertyui', '63-65 Kilmacud Road Lower, Blackrock', '', 'Dublin', 'HI', 'A94 C840', '2022-02-12', '2025-04-21', 'JTHGS', 'TYREZA', 'No', '', 'UIYTRE', '63-65 Kilmacud Road Lower, Blackrock', '', 'Dublin', 'HI', 'A94 C840', '2022-03-21', '2026-06-23', 'QERT67', 'DFTYUI', 'No', '', 'ZERT6789', '63-65 Kilmacud Road Lower, Blackrock', '', 'Dublin', 'AK', 'A94 C840', '2022-03-21', '2025-03-12', '56', 'No', '', 'No', '', '', 'pending', '2026-01-28 08:42:38', '2026-01-28 08:42:38');

-- --------------------------------------------------------
-- Table structure for table `nclex_session_registrations`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `nclex_session_registrations`;
CREATE TABLE `nclex_session_registrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` int NOT NULL,
  `user_id` int NOT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nursing_school` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `years_attended` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credentials_started` enum('yes','no') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `motivation` text COLLATE utf8mb4_unicode_ci,
  `comments` text COLLATE utf8mb4_unicode_ci,
  `payment_status` enum('pending','completed','failed','refunded') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_amount` decimal(10,2) DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registered_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `nclex_session_registrations`
-- --------------------------------------------------------

-- No data in table `nclex_session_registrations`

-- --------------------------------------------------------
-- Table structure for table `nclex_sessions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `nclex_sessions`;
CREATE TABLE `nclex_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `session_type` enum('3-months','6-months') COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `max_students` int DEFAULT '50',
  `current_students` int DEFAULT '0',
  `status` enum('open','full','closed','completed') COLLATE utf8mb4_unicode_ci DEFAULT 'open',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `nclex_sessions`
-- --------------------------------------------------------

-- No data in table `nclex_sessions`

-- --------------------------------------------------------
-- Table structure for table `payment_config`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `payment_config`;
CREATE TABLE `payment_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_enabled` tinyint(1) DEFAULT '0',
  `config_data` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_method` (`payment_method`),
  UNIQUE KEY `payment_method_2` (`payment_method`),
  UNIQUE KEY `payment_method_3` (`payment_method`),
  UNIQUE KEY `payment_method_4` (`payment_method`),
  UNIQUE KEY `payment_method_5` (`payment_method`),
  UNIQUE KEY `payment_method_6` (`payment_method`),
  UNIQUE KEY `payment_method_7` (`payment_method`),
  UNIQUE KEY `payment_method_8` (`payment_method`),
  UNIQUE KEY `payment_method_9` (`payment_method`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `payment_config`
-- --------------------------------------------------------

INSERT INTO `payment_config` (`id`, `payment_method`, `is_enabled`, `config_data`, `created_at`, `updated_at`) VALUES
('1', 'stripe', '1', '{\"publishable_key\":\"pk_live_51MFfueJD3YPggaoE7FO5vYuhEBf0H8tg0Qg0N1qv2o88nKGLV6jzyhcl51tobbyuwMNN6QGt8ILZfdm7i2Jd6iCG00KrYJOu2l\",\"secret_key\":\"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\",\"webhook_secret\":\"\"}', '2025-12-16 10:55:16', '2026-01-29 12:18:35'),
('2', 'paypal', '1', '{\"client_id\":\"Af9rdstDIjShKWRUR3DXgE-9C59Bjh5Vab21bw8DGt-pCac8ZLkA1I7vVvYsigV5yrEnCbFS9gBrgvFG\",\"client_secret\":\"ELX-hhJ1fnUkA75zuerk4UwruVqv7zGI8LgJaX4lIp5LbKjsGnR9xsI9wg51Mpa_qC4IjC0ks-f8Vdbw\",\"mode\":\"sandbox\"}', '2025-12-16 10:55:16', '2026-01-30 15:05:37'),
('19', 'zelle', '1', '{}', '2026-01-29 12:31:04', '2026-01-31 07:24:11'),
('20', 'cashapp', '0', '{}', '2026-01-29 12:31:04', '2026-01-29 12:31:28'),
('21', 'bank_deposit', '0', '{}', '2026-01-29 12:31:04', '2026-01-29 12:31:04');

-- --------------------------------------------------------
-- Table structure for table `purchases`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `purchases`;
CREATE TABLE `purchases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `course_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `purchased_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_purchase` (`user_id`,`course_id`),
  KEY `course_id` (`course_id`),
  CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchases_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `purchases`
-- --------------------------------------------------------

INSERT INTO `purchases` (`id`, `user_id`, `course_id`, `amount`, `payment_method`, `payment_transaction_id`, `payment_status`, `purchased_at`) VALUES
('1', '2', '1', '299.99', 'zelle', '23456789', 'pending', '2026-01-31 07:36:29');

-- --------------------------------------------------------
-- Table structure for table `resources`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `resources`;
CREATE TABLE `resources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lesson_id` int DEFAULT NULL,
  `chapter_id` int DEFAULT NULL,
  `course_id` int DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` enum('pdf','doc','docx','ppt','pptx','other') COLLATE utf8mb4_unicode_ci DEFAULT 'pdf',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `lesson_id` (`lesson_id`),
  KEY `chapter_id` (`chapter_id`),
  KEY `course_id` (`course_id`),
  CONSTRAINT `resources_ibfk_1` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `resources_ibfk_2` FOREIGN KEY (`chapter_id`) REFERENCES `chapters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `resources_ibfk_3` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `resources`
-- --------------------------------------------------------

-- No data in table `resources`

-- --------------------------------------------------------
-- Table structure for table `service_forms`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `service_forms`;
CREATE TABLE `service_forms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `is_active` (`is_active`),
  CONSTRAINT `service_forms_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `service_forms`
-- --------------------------------------------------------

-- No data in table `service_forms`

-- --------------------------------------------------------
-- Table structure for table `service_plans`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `service_plans`;
CREATE TABLE `service_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `duration_months` int NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `display_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `service_plans_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `service_plans`
-- --------------------------------------------------------

-- No data in table `service_plans`

-- --------------------------------------------------------
-- Table structure for table `service_requests`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `service_requests`;
CREATE TABLE `service_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `form_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `form_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_amount` decimal(10,2) DEFAULT NULL,
  `request_status` enum('pending','in_progress','completed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `admin_notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `plan_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `form_id` (`form_id`),
  KEY `user_id` (`user_id`),
  KEY `payment_status` (`payment_status`),
  KEY `request_status` (`request_status`),
  KEY `plan_id` (`plan_id`),
  CONSTRAINT `service_requests_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_requests_ibfk_2` FOREIGN KEY (`form_id`) REFERENCES `service_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_requests_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `service_requests`
-- --------------------------------------------------------

-- No data in table `service_requests`

-- --------------------------------------------------------
-- Table structure for table `service_subscription_payments`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `service_subscription_payments`;
CREATE TABLE `service_subscription_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subscription_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'completed',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `subscription_id` (`subscription_id`),
  CONSTRAINT `service_subscription_payments_ibfk_1` FOREIGN KEY (`subscription_id`) REFERENCES `service_subscriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `service_subscription_payments`
-- --------------------------------------------------------

-- No data in table `service_subscription_payments`

-- --------------------------------------------------------
-- Table structure for table `service_subscriptions`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `service_subscriptions`;
CREATE TABLE `service_subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `plan_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `request_id` int DEFAULT NULL,
  `amount_per_interval` decimal(10,2) NOT NULL,
  `billing_interval` enum('week','month') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'month',
  `start_date` date NOT NULL,
  `next_payment_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('active','cancelled','completed') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `plan_id` (`plan_id`),
  KEY `service_id` (`service_id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `next_payment_date` (`next_payment_date`),
  CONSTRAINT `service_subscriptions_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_subscriptions_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `service_plans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_subscriptions_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `service_subscriptions`
-- --------------------------------------------------------

-- No data in table `service_subscriptions`

-- --------------------------------------------------------
-- Table structure for table `services`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `display_order` int DEFAULT '0',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `recurring_enabled` tinyint(1) DEFAULT '0',
  `billing_interval` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'month',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `display_order` (`display_order`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `services`
-- --------------------------------------------------------

INSERT INTO `services` (`id`, `title`, `description`, `image`, `icon`, `price`, `display_order`, `status`, `created_at`, `updated_at`, `recurring_enabled`, `billing_interval`) VALUES
('4', 'Tutoring Services 6 weeks', 'Our tutoring services offer personalized, one-on-one or small-group instruction tailored to your specific learning needs. Over a period of 6, 8, or 10 weeks, we focus on strengthening core concepts, improving performance, and building confidence. Sessions are structured to ensure steady progress, with ongoing support and guidance throughout the program.', 'uploads/services/1769434917_International nurse receiving sponsorship assistance, professional meeting with advisor, flags or globe subtly in background, supportive and hopeful atmosphere, professional office setting, high-quality realistic im.jpg', '', '1800.00', '1000000', 'active', '2026-01-26 14:41:57', '2026-01-26 14:47:36', '0', 'month'),
('5', 'Review Classes 3 months,', 'Review classes are designed to help students reinforce previously learned material and prepare effectively for exams or professional assessments. Offered over 3 or 6 months, these classes provide comprehensive content review, practice exercises, and guided discussions to ensure a solid understanding of key topics.', 'uploads/services/1769435050_Inspirational healthcare education visual._A focused nurse studying with a laptop and medical textbooks, combined with subtle visual elements of growth and progress._Bright, uplifting atmosphere with warm natural li.jpg', '', '1500.00', '1000000', 'active', '2026-01-26 14:44:10', '2026-01-26 14:48:05', '0', 'month'),
('6', 'Registration Process', 'We provide full assistance with the registration process to ensure all forms, documents, and requirements are completed correctly and on time. This service reduces errors, saves time, and helps you navigate the process with confidence and peace of mind.', 'uploads/services/1769435224_Official medical license endorsement concept, nurse reviewing approved documents with official stamps and seals, clipboard and pen, American healthcare setting, professional office background, clean, trustworthy (1).jpg', '', '2500.00', '100000', 'active', '2026-01-26 14:47:04', '2026-01-26 14:47:04', '0', 'month'),
('7', 'Bundle Review + Registration Process', 'This bundled service combines structured review classes with complete registration assistance. It is ideal for individuals who want both academic preparation and administrative support in one package, ensuring a smooth and stress-free experience from start to finish.', 'uploads/services/1769435375_Official medical license endorsement concept, nurse reviewing approved documents with official stamps and seals, clipboard and pen, American healthcare setting, professional office background, clean, trustworthy, hi.jpg', '', '5300.00', '1000000', 'active', '2026-01-26 14:49:35', '2026-01-26 14:49:35', '0', 'month'),
('8', 'Study Plan', 'Our study plan service delivers a personalized and organized roadmap based on your goals, timeline, and learning style. It outlines daily and weekly tasks, recommended resources, and strategies to maximize productivity and maintain consistent progress.', 'uploads/services/1769435470_Professional and modern healthcare visual showing diverse international nurses wearing blue and white scrubs, standing confidently in a bright U.S. hospital environment. Clean and minimalist corporate style, soft na.jpg', '', '150.00', '1000000', 'active', '2026-01-26 14:51:10', '2026-01-26 14:51:10', '0', 'month'),
('9', 'Professional Resume', 'We create a professional, well-structured resume that highlights your skills, experience, and achievements. This service ensures your resume meets industry standards and presents you as a strong, competitive candidate for academic or professional opportunities.', 'uploads/services/1769435566_Premium educational excellence concept._Close-up of a professional nurse confidently reviewing clinical material on a digital tablet._Clean medical setting, modern equipment, organized environment._Sharp lightin (1).jpg', '', '100.00', '1000000', 'active', '2026-01-26 14:52:46', '2026-01-26 14:52:46', '0', 'month'),
('10', 'Credential Evaluation Orientation', 'Our credential evaluation orientation helps you understand how your academic or professional credentials are assessed. We explain the process, required documentation, and evaluation standards, ensuring you are well prepared before submitting your credentials.', 'uploads/services/1769435720_Professional orientation session for international healthcare workers, presenter explaining credential evaluation process using a screen, participants taking notes, corporate training room, organized and welcomi (1).jpg', '', '100.00', '1000000', 'active', '2026-01-26 14:55:20', '2026-01-26 14:55:20', '0', 'month'),
('11', 'Sponsorship Program Assistance 1 hour call', 'This one-hour consultation offers guidance on sponsorship programs, eligibility criteria, and application procedures. We help you understand your options and provide practical advice to improve your chances of success.', 'uploads/services/1769435871_International nurse receiving sponsorship assistance, professional meeting with advisor, flags or globe subtly in background, supportive and hopeful atmosphere, professional office setting, high-quality realistic im.jpg', '', '100.00', '1000000', 'active', '2026-01-26 14:57:51', '2026-01-26 14:57:51', '0', 'month'),
('12', 'Book a Call with Coach Sandy 30-minute', 'Schedule a 30-minute one-on-one call with Coach Sandy to receive personalized guidance, answer your questions, and discuss your goals. This session is designed to provide clarity, direction, and actionable advice.', 'uploads/services/1769436033_sandy.jpeg', '', '50.00', '1000000', 'active', '2026-01-26 15:00:33', '2026-01-26 15:00:33', '0', 'month'),
('13', 'Purchase over Q Bank (Coming Soon)', 'Our Q Bank feature is coming soon and will provide access to a collection of questions and learning resources designed to support study, practice, and exam preparation.', 'uploads/services/1769436171_Professional orientation session for international healthcare workers, presenter explaining credential evaluation process using a screen, participants taking notes, corporate training room, organized and welcoming a.jpg', '', '0.00', '1000000', 'active', '2026-01-26 15:02:51', '2026-01-26 15:02:51', '0', 'month');

-- --------------------------------------------------------
-- Table structure for table `session_registration_courses`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `session_registration_courses`;
CREATE TABLE `session_registration_courses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `registration_id` int NOT NULL,
  `course_id` int NOT NULL,
  `assigned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `assigned_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_registration_course` (`registration_id`,`course_id`),
  KEY `idx_registration_id` (`registration_id`),
  KEY `idx_course_id` (`course_id`),
  CONSTRAINT `fk_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_registration` FOREIGN KEY (`registration_id`) REFERENCES `session_registrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `session_registration_courses`
-- --------------------------------------------------------

INSERT INTO `session_registration_courses` (`id`, `registration_id`, `course_id`, `assigned_at`, `assigned_by`) VALUES
('1', '26', '10', '2026-01-31 07:25:43', '1');

-- --------------------------------------------------------
-- Table structure for table `session_registrations`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `session_registrations`;
CREATE TABLE `session_registrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nursing_school` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `years_attended` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_duration` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credentials_started` enum('Yes','No') COLLATE utf8mb4_unicode_ci NOT NULL,
  `motivation` text COLLATE utf8mb4_unicode_ci,
  `comments` text COLLATE utf8mb4_unicode_ci,
  `registration_fee` decimal(10,2) DEFAULT '50.00',
  `tax` decimal(10,2) DEFAULT '3.99',
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`),
  KEY `idx_payment_status` (`payment_status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `session_registrations`
-- --------------------------------------------------------

INSERT INTO `session_registrations` (`id`, `user_id`, `first_name`, `last_name`, `email`, `phone`, `nursing_school`, `years_attended`, `session_duration`, `credentials_started`, `motivation`, `comments`, `registration_fee`, `tax`, `total_amount`, `payment_method`, `payment_transaction_id`, `payment_status`, `created_at`, `updated_at`) VALUES
('1', NULL, 'fghj', 'dtyuio', 'mailsecours60@gmail.com', '0965646608', 'rdtfyuio', '345678', '3 Months', 'No', 'TRYUIOP', 'RFTYUIOP°', '50.00', '3.99', '53.99', 'cashapp', 'ZERTYUIOP', 'pending', '2026-01-27 23:44:24', '2026-01-27 23:44:24'),
('2', '2', 'GlenA', 'Dem', 'glen@gmail.com', '54321564534', 'HJHGDFSD', '432', '3 Months', 'Yes', 'TYUIOP¨£', 'ETRYUIOP¨£', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 12:20:24', '2026-01-29 12:20:24'),
('3', '2', 'Glena', 'Dem', 'glenn@gmail.com', '54321564534', 'HJHGDFSD', '432', '3 Months', 'No', 'frgtyuji', 'retyuiop', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 12:31:51', '2026-01-29 12:31:51'),
('4', '2', 'Glenaa', 'Dem', 'glen1234@gmail.com', '54321564534', 'HJHGDFSD', '432', '6 Months', 'Yes', 'RTYUIOP', '¨RZETYUIOP', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 12:39:40', '2026-01-29 12:39:40'),
('5', '2', 'Glena', 'Dem', 'glen@gmail.com', '54321564534', 'HJHGDFSD', '432', '6 Months', 'No', 'frgtyuiop', 'tyuio', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 15:35:25', '2026-01-29 15:35:25'),
('6', '2', 'Glena', 'Dem', 'glen@gmail.com', '54321564534', 'HJHGDFSD', '432', '6 Months', 'No', 'frgtyuiop', 'tyuio', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 15:37:21', '2026-01-29 15:37:21'),
('7', '2', 'Glena', 'Dem', 'glen@gmail.com', '54321564534', 'HJHGDFSD', '432', '3 Months', 'Yes', 'tyuiop', '^rtryuio', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 15:42:03', '2026-01-29 15:42:03'),
('8', '2', 'Glena', 'Dem', 'glen@gmail.com', '54321564534', 'HJHGDFSD', '432', '3 Months', 'Yes', 'tyuiop', '^rtryuio', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 15:49:02', '2026-01-29 15:49:02'),
('9', '2', 'Glena', 'Dem', 'glen@gmail.com', '54321564534', 'HJHGDFSD', '432', '3 Months', 'Yes', 'tyuiop', '^rtryuio', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 15:59:07', '2026-01-29 15:59:07'),
('10', '2', 'Glena', 'Dem', 'glen@gmail.com', '54321564534', 'HJHGDFSD', '432', '3 Months', 'Yes', 'tyuiop', '^rtryuio', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 15:59:16', '2026-01-29 15:59:16'),
('11', '2', 'Glena', 'Dem', 'glen@gmail.com', '54321564534', 'HJHGDFSD', '432', '3 Months', 'Yes', 'tyuiop', '^rtryuio', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 16:08:31', '2026-01-29 16:08:31'),
('12', '2', 'Glena', 'Dem', 'glen@gmail.com', '54321564534', 'HJHGDFSD', '432', '3 Months', 'Yes', 'tyuiop', '^rtryuio', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 16:09:47', '2026-01-29 16:09:47'),
('13', '2', 'Glena', 'Dem', 'glen@gmail.com', '54321564534', 'HJHGDFSD', '432', '3 Months', 'Yes', 'tyuiop', '^rtryuio', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 16:09:56', '2026-01-29 16:09:56'),
('14', '2', 'Glena', 'Dem', 'glen@gmail.com', '54321564534', 'HJHGDFSD', '432', '3 Months', 'Yes', 'tyuiop', '^rtryuio', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 16:12:44', '2026-01-29 16:12:44'),
('15', '2', 'Glena', 'Dem', 'glen@gmail.com', '54321564534', 'HJHGDFSD', '432', '3 Months', 'Yes', 'tyuiop', '^rtryuio', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-29 16:13:29', '2026-01-29 16:13:29'),
('16', '2', 'Glen', 'Dempsey', 'mailsecours60@gmail.com', '0965646608', 'rdtfyuio', '345678', '3 Months', 'No', 'iuytr', 'yutr', '50.00', '3.99', '53.99', 'paypal', NULL, 'pending', '2026-01-30 15:02:49', '2026-01-30 15:02:49'),
('17', '2', 'Glen', 'Dempsey', 'mailsecours60@gmail.com', '0965646608', 'rdtfyuio', '345678', '3 Months', 'No', 'iuytr', 'yutr', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-30 15:03:20', '2026-01-30 15:03:20'),
('18', '2', 'Glen', 'Dempsey', 'mailsecours60@gmail.com', '0965646608', 'rdtfyuio', '345678', '3 Months', 'No', 'iuytr', 'yutr', '50.00', '3.99', '53.99', 'paypal', NULL, 'pending', '2026-01-30 15:03:29', '2026-01-30 15:03:29'),
('19', '2', 'Glen', 'Dempsey', 'mailsecours60@gmail.com', '0965646608', 'rdtfyuio', '345678', '3 Months', 'No', 'iuytr', 'yutr', '50.00', '3.99', '53.99', 'paypal', NULL, 'pending', '2026-01-30 15:05:56', '2026-01-30 15:05:56'),
('20', '2', 'Glen', 'Dempsey', 'mailsecours60@gmail.com', '0965646608', 'rdtfyuio', '345678', '3 Months', 'No', 'iuytr', 'yutr', '50.00', '3.99', '53.99', 'paypal', NULL, 'pending', '2026-01-30 15:14:00', '2026-01-30 15:14:00'),
('21', '2', 'Glen', 'Dempsey', 'mailsecours60@gmail.com', '0965646608', 'rdtfyuio', '345678', '3 Months', 'No', 'iuytr', 'yutr', '50.00', '3.99', '53.99', 'paypal', NULL, 'pending', '2026-01-30 15:14:14', '2026-01-30 15:14:14'),
('22', '2', 'Glen', 'Dempsey', 'mailsecours60@gmail.com', '0965646608', 'rdtfyuio', '345678', '3 Months', 'No', 'iuytr', 'yutr', '50.00', '3.99', '53.99', 'paypal', NULL, 'pending', '2026-01-30 15:20:49', '2026-01-30 15:20:49'),
('23', '2', 'Glen', 'Dempsey', 'mailsecours60@gmail.com', '0965646608', 'rdtfyuio', '345678', '3 Months', 'Yes', 'DFGVHJN', 'CRTVYHUJI', '50.00', '3.99', '53.99', 'paypal', NULL, 'pending', '2026-01-31 07:23:18', '2026-01-31 07:23:18'),
('24', '2', 'Glen', 'Dempsey', 'mailsecours60@gmail.com', '0965646608', 'rdtfyuio', '345678', '3 Months', 'Yes', 'DFGVHJN', 'CRTVYHUJI', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-31 07:23:43', '2026-01-31 07:23:43'),
('25', '2', 'Glen', 'Dempsey', 'mailsecours60@gmail.com', '0965646608', 'rdtfyuio', '345678', '3 Months', 'Yes', 'DFGVHJN', 'CRTVYHUJI', '50.00', '3.99', '53.99', 'stripe', NULL, 'pending', '2026-01-31 07:24:33', '2026-01-31 07:24:33'),
('26', '2', 'Glen', 'Dempsey', 'mailsecours60@gmail.com', '0965646608', 'rdtfyuio', '345678', '3 Months', 'Yes', 'DFGVHJN', 'CRTVYHUJI', '50.00', '3.99', '53.99', 'zelle', '23456789', 'completed', '2026-01-31 07:24:43', '2026-01-31 07:25:57');

-- --------------------------------------------------------
-- Table structure for table `team_members`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `team_members`;
CREATE TABLE `team_members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_order` int DEFAULT '0',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `display_order` (`display_order`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `team_members`
-- --------------------------------------------------------

INSERT INTO `team_members` (`id`, `first_name`, `last_name`, `position`, `description`, `email`, `phone`, `photo`, `facebook_url`, `twitter_url`, `linkedin_url`, `instagram_url`, `display_order`, `status`, `created_at`, `updated_at`) VALUES
('1', 'TOM', 'OMS', 'FOUND', 'FOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUNDFOUND', 'mailsecours60@gmail.com', '0965646608', 'uploads/team/1766520986_573a37c6-9987-4dce-b6a6-1ed0d3257b0c.webp', '', '', '', '', '1', 'active', '2025-12-23 22:16:26', '2025-12-23 22:16:26'),
('2', 'Graciela Cadet', 'Dornaivil', 'COACH', 'Graciéla Cadet is a Nurse Leader who has worked in various role including Critical Care (as a Flight Nurse), Healthcare Management (as Deputy Chief Nursing Officer) and Teaching. She holds a master’s degree in business administration, she was part of the first cohort of the Global Nurse Executive Fellowship of Partners in Health and a HEAL alumni as well. She is a strong advocate for nursing leadership and has worked to improve healthcare systems in Haiti. Additionally, Graciéla has worked on projects focused on quality improvement, she has been led by a desire to promote social justice and equity in healthcare. Her passion for teaching and learning aims her to inspire and prepare future generations of nurses, through the andragogy techniques, advancing the profession and enhancing patient care. EDUCATION : License in nursing, École Nationale d\'Infirmières de Port-au-Prince, 2005–2008 MBA, Interamerican University of Puerto Rico, 2019', '', '', 'uploads/team/1768677160_graciela.webp', '', '', '', '', '0', 'active', '2026-01-17 20:12:40', '2026-01-17 20:12:40');

-- --------------------------------------------------------
-- Table structure for table `testimonials`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `testimonials`;
CREATE TABLE `testimonials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` int DEFAULT '5',
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `testimonials`
-- --------------------------------------------------------

INSERT INTO `testimonials` (`id`, `name`, `email`, `comment`, `rating`, `status`, `created_at`, `updated_at`) VALUES
('1', 'Glen Dempsey', 'mailsecours60@gmail.com', 'Hello i very happy for what you do', '5', 'approved', '2026-01-17 10:54:09', '2026-01-17 10:54:27'),
('2', 'Ricardo Alzinord', 'klyratech@gmail.com', 'Good Service', '5', 'approved', '2026-01-17 20:31:44', '2026-01-17 20:32:09'),
('3', 'Ricardo Alzinord', 'klyratech@gmail.com', 'Good Service', '5', 'pending', '2026-01-17 20:32:15', '2026-01-17 20:32:15');

-- --------------------------------------------------------
-- Table structure for table `user_progress`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `user_progress`;
CREATE TABLE `user_progress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `course_id` int NOT NULL,
  `chapter_id` int DEFAULT NULL,
  `lesson_id` int DEFAULT NULL,
  `completed` tinyint(1) DEFAULT '0',
  `progress_percentage` decimal(5,2) DEFAULT '0.00',
  `last_accessed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `course_id` (`course_id`),
  KEY `chapter_id` (`chapter_id`),
  KEY `lesson_id` (`lesson_id`),
  CONSTRAINT `user_progress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_progress_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_progress_ibfk_3` FOREIGN KEY (`chapter_id`) REFERENCES `chapters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_progress_ibfk_4` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `user_progress`
-- --------------------------------------------------------

-- No data in table `user_progress`

-- --------------------------------------------------------
-- Table structure for table `users`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('user','admin','coach') COLLATE utf8mb4_unicode_ci DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `users`
-- --------------------------------------------------------

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `phone`, `role`, `created_at`, `updated_at`) VALUES
('1', 'Admin', 'Orchidee', 'admin@orchideellc.com', '$2y$10$l87PMHGQYYJ9IuGCzpYcQOG.HeJ9ywkPIOdP9FFOXk4P988kdIqBC', NULL, 'admin', '2025-12-15 19:08:55', '2025-12-15 19:08:55'),
('2', 'Glenn', 'Dempsey', 'glen@gmail.com', '$2y$10$erB7sGPypTsFbQZ0vcZ7Ru.hxOY8ecRf26yU9KBaPbGyN2u2ou64S', '0965646608', 'user', '2025-12-15 19:20:14', '2025-12-23 22:08:50'),
('3', 'Ray', 'Ray', 'coach@gmail.com', '$2y$10$E1DQ66qUxypTun49PQY7v.2voLp13sCwygvWOvoEgboUKyrpxLRFm', NULL, '', '2026-01-30 18:44:29', '2026-01-30 18:44:29'),
('4', 'Ray', 'Ray', 'ch@gmail.com', '$2y$10$sAmIoBBDL4pgjf1T87FkFuzYM9m1RFSXKCqnyeJQdfHUYisBdqFum', NULL, 'coach', '2026-01-31 06:40:17', '2026-01-31 06:40:17');

-- --------------------------------------------------------
-- Table structure for table `webinar_registrations`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `webinar_registrations`;
CREATE TABLE `webinar_registrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `webinar_id` int NOT NULL,
  `user_id` int NOT NULL,
  `registered_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `attended` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_registration` (`webinar_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `webinar_registrations`
-- --------------------------------------------------------

-- No data in table `webinar_registrations`

-- --------------------------------------------------------
-- Table structure for table `webinars`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `webinars`;
CREATE TABLE `webinars` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `meeting_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting_password` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scheduled_date` datetime NOT NULL,
  `duration_minutes` int DEFAULT '60',
  `max_participants` int DEFAULT '100',
  `status` enum('scheduled','live','completed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'scheduled',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Dumping data for table `webinars`
-- --------------------------------------------------------

-- No data in table `webinars`

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

COMMIT;
